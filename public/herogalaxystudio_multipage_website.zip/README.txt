HERO GALAXY STUDIO MULTI-PAGE WEBSITE

Pages:
index.html
studio.html
games.html
development.html
media.html
contact.html

Upload ALL files plus the assets folder together to Cloudflare.
This version uses separate pages instead of #games or #media anchors.
