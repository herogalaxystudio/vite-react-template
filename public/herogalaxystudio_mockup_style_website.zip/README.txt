HERO GALAXY STUDIO WEBSITE PACKAGE

This package contains a complete responsive website inspired by the approved mockup.

FILES
- index.html
- styles.css
- script.js
- assets/hero-galaxy-logo.png
- assets/design-reference.png

HOW TO USE
1. Open index.html to preview locally.
2. Upload all files and folders to your Cloudflare Workers/Pages site.
3. Keep the assets folder next to index.html.
4. Replace placeholder game names and cards with your real games later.

IMPORTANT
Hero Galaxy Studio is presented as a GAME DEVELOPMENT STUDIO for multiple games,
not as one single game.
