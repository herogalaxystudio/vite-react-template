import { useState } from 'react'

const games = [
  {
    title: 'Game Project 01',
    status: 'IN DEVELOPMENT',
    genre: 'Action • Adventure • Platformer',
    platform: 'PC / CONSOLE',
  },
  {
    title: 'Game Project 02',
    status: 'COMING SOON',
    genre: 'Original Hero Galaxy Studio Project',
    platform: 'PC / CONSOLE',
  },
  {
    title: 'Game Project 03',
    status: 'PROTOTYPE',
    genre: 'Experimental Gameplay Project',
    platform: 'PC / CONSOLE',
  },
]

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <div className="site">
      <header className="topbar">
        <a className="brand" href="#home">
          <img src="/assets/hero-galaxy-logo.png" alt="Hero Galaxy Studio" />
          <div>
            <strong>HERO GALAXY</strong>
            <span>STUDIO</span>
          </div>
        </a>

        <button className="menuButton" onClick={() => setMenuOpen(!menuOpen)}>☰</button>

        <nav className={menuOpen ? 'nav open' : 'nav'}>
          <a href="#home">HOME</a>
          <a href="#studio">OUR STUDIO</a>
          <a href="#games">OUR GAMES</a>
          <a href="#development">DEVELOPMENT</a>
          <a href="#media">MEDIA</a>
          <a href="#contact">CONTACT</a>
        </nav>
      </header>

      <main>
        <section id="home" className="hero">
          <div className="stars" />
          <div className="heroCopy">
            <p className="eyebrow">INDEPENDENT GAME DEVELOPMENT STUDIO</p>
            <img className="heroLogo" src="/assets/hero-galaxy-logo.png" alt="Hero Galaxy Studio" />
            <h1>
              WE CREATE <span>GAMES, HEROES</span><br />
              & NEW WORLDS
            </h1>
            <p className="lead">
              Hero Galaxy Studio creates original games, characters, stories, gameplay systems,
              cinematic adventures, and imaginative worlds for PC and console platforms.
            </p>
            <div className="actions">
              <a className="primaryBtn" href="#games">OUR GAMES →</a>
              <a className="secondaryBtn" href="#studio">ABOUT OUR STUDIO</a>
            </div>
          </div>

          <div className="heroArt">
            <div className="planet large" />
            <div className="planet small" />
            <div className="ring" />
            <div className="city" />
          </div>
        </section>

        <section id="studio" className="section darkSection">
          <p className="eyebrow">OUR STUDIO</p>
          <h2>WE BUILD INTERACTIVE WORLDS.</h2>
          <p className="sectionLead">
            Hero Galaxy Studio is an independent developer focused on original worlds,
            memorable heroes, action, adventure, platforming, boss battles and cinematic gameplay.
          </p>
          <div className="featureGrid">
            <article><span>🌌</span><h3>Original Worlds</h3><p>Characters, planets, environments, enemies and stories.</p></article>
            <article><span>⚔️</span><h3>Action & Adventure</h3><p>Combat, exploration, abilities, movement and boss encounters.</p></article>
            <article><span>🎮</span><h3>PC & Console</h3><p>Games designed for PC and console platforms only.</p></article>
          </div>
        </section>

        <section id="games" className="section">
          <div className="sectionHeader">
            <div>
              <p className="eyebrow">OUR GAMES</p>
              <h2>ALL GAMES. ONE STUDIO.</h2>
            </div>
          </div>
          <div className="gamesGrid">
            {games.map((game, index) => (
              <article className="gameCard" key={game.title}>
                <div className={`gameArt gameArt${index + 1}`}>
                  <span className="status">{game.status}</span>
                  <strong>{String(index + 1).padStart(2, '0')}</strong>
                </div>
                <div className="gameInfo">
                  <h3>{game.title}</h3>
                  <p>{game.genre}</p>
                  <div className="tags"><span>{game.platform}</span></div>
                  <button>LEARN MORE</button>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section id="development" className="section darkSection">
          <p className="eyebrow">DEVELOPMENT</p>
          <h2>FROM IDEA TO PLAYABLE EXPERIENCE.</h2>
          <div className="developmentGrid">
            <article><h3>Game Design</h3><p>Mechanics, levels, progression, missions and player experience.</p></article>
            <article><h3>Gameplay Systems</h3><p>Combat, movement, abilities, enemies, bosses, UI and progression.</p></article>
            <article><h3>World Building</h3><p>Original environments, characters, stories and visual identities.</p></article>
            <article><h3>Cinematics & VFX</h3><p>Story scenes, camera direction, trailers and visual effects.</p></article>
          </div>
        </section>

        <section id="media" className="section mediaSection">
          <p className="eyebrow">MEDIA</p>
          <h2>TRAILERS, GAMEPLAY & ARTWORK.</h2>
          <div className="mediaGrid">
            <article><div className="mediaIcon">▶</div><h3>Gameplay Videos</h3><p>Add YouTube gameplay and trailers here.</p></article>
            <article><div className="mediaIcon">▧</div><h3>Screenshots</h3><p>Show screenshots from your PC and console games.</p></article>
            <article><div className="mediaIcon">✦</div><h3>Concept Art</h3><p>Characters, bosses, worlds and promotional art.</p></article>
          </div>
        </section>

        <section id="contact" className="section contactSection">
          <p className="eyebrow">CONTACT</p>
          <h2>HERO GALAXY STUDIO</h2>
          <p>Business inquiries • Publishing • Platform partnerships • Press • Collaborations</p>
          <a className="primaryBtn" href="mailto:contact@herogalaxystudio.com">CONTACT US</a>
        </section>
      </main>

      <footer>
        <img src="/assets/hero-galaxy-logo.png" alt="Hero Galaxy Studio" />
        <div>
          <strong>HERO GALAXY STUDIO</strong>
          <p>Independent Game Development Studio • PC & Console</p>
        </div>
        <span>© {new Date().getFullYear()} Hero Galaxy Studio</span>
      </footer>
    </div>
  )
}
