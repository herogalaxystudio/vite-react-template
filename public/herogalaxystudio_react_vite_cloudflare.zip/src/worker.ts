import { Hono } from 'hono'

type Bindings = {
  ASSETS: Fetcher
}

const app = new Hono<{ Bindings: Bindings }>()

app.get('/api/health', (c) => c.json({ ok: true, studio: 'Hero Galaxy Studio' }))

app.all('*', async (c) => {
  return c.env.ASSETS.fetch(c.req.raw)
})

export default app
