# Hero Galaxy Studio — React + Vite + Cloudflare

This project is ready to replace the default Cloudflare `vite-react-template`.

## Upload to GitHub

Upload the contents of this folder to the root of:

`herogalaxystudio/vite-react-template`

Important files:
- `package.json`
- `vite.config.ts`
- `wrangler.json`
- `index.html`
- `src/`
- `public/`

## Build

```bash
npm install
npm run build
```

## Deploy

```bash
npm run deploy
```

## Notes

- Studio platforms are PC and Console only.
- The logo is stored at `public/assets/hero-galaxy-logo.png`.
- The Cloudflare Worker includes `/api/health`.
- The site uses SPA fallback routing through Static Assets.
